"""Quick sanity checks for each module on its own (no video needed). Run: python examples/module_smoke_test.py"""
import os, sys
import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from facevitals_enhancements import (BackgroundIlluminationCanceller, FaceRoiBuilder, HRTracker, LightingCompensator,
                                     ROIStabilizer, SkinToneAdapter, SpectralRefiner, TemporalResampler,
                                     smoothness_priors_detrend, soft_mask_from_polygon)

ok = lambda c, msg: print(("PASS  " if c else "FAIL  ") + msg)
rng = np.random.default_rng(0)

# 1) skin tone: ITA category from flat swatches in good light
for rgb, expect in [((235, 200, 180), "very_light"), ((205, 160, 130), None), ((140, 95, 70), None), ((80, 55, 40), "dark")]:
    img = np.full((60, 60, 3), rgb[::-1], np.uint8)
    ad = SkinToneAdapter()
    for _ in range(40):
        ad.update(img, np.ones((60, 60), bool))
    pr = ad.profile
    print(f"      swatch {rgb} -> ITA {pr.ita:6.1f}  category={pr.category:12s} window={pr.window_sec}s")
    if expect:
        ok(pr.category == expect, f"swatch {rgb} classified {expect}")

# 2) occlusion ROI builder: rotation-aware polygons stay inside the face
lm = np.zeros((468, 2))
lm[10], lm[152], lm[234], lm[454] = (160, 40), (160, 210), (95, 125), (225, 125)
for i, p in {9: (160, 95), 1: (160, 130), 129: (145, 135), 358: (175, 135), 61: (143, 168), 291: (177, 168),
             33: (128, 105), 263: (192, 105), 145: (130, 110), 374: (190, 110)}.items():
    lm[i] = p
for i, x in zip([70, 63, 105, 66, 107], [118, 126, 134, 142, 150]): lm[i] = (x, 88)
for i, x in zip([336, 296, 334, 293, 300], [170, 178, 186, 194, 202]): lm[i] = (x, 88)
polys = FaceRoiBuilder().from_landmarks(lm)
inside = all(((p[:, 0] > 95) & (p[:, 0] < 225) & (p[:, 1] > 40) & (p[:, 1] < 210)).all() for p in polys.values())
ok(inside, "FaceRoiBuilder polygons lie inside the face box (check draw_debug on real faces!)")

# 3) lighting: background regression removes a shared colour-changing light
fs, T = 30.0, 300
t = np.arange(T) / fs
pulse = 0.004 * np.sin(2 * np.pi * 1.2 * t)
light = 1 + 0.03 * np.sin(2 * np.pi * 1.5 * t + 0.5)[:, None] * np.array([1.0, 0.5, 1.5])
face = 100 * light * (1 + pulse[:, None] * np.array([0.43, 1.0, 0.69]))
bg = 120 * light
clean = BackgroundIlluminationCanceller().cancel(face, bg)
def hr_power(x, f):
    s = np.abs(np.fft.rfft((x - x.mean()) * np.hanning(len(x)), 4096)) ** 2; fr = np.fft.rfftfreq(4096, 1 / fs)
    return s[np.argmin(abs(fr - f))]
g0, g1 = face[:, 1], clean[:, 1]
ok(hr_power(g1, 1.5) < 0.05 * hr_power(g0, 1.5), "background canceller removes the 1.5 Hz light flicker (>95%)")
ok(hr_power(g1, 1.2) > 0.5 * hr_power(g0, 1.2), "...and keeps the 1.2 Hz pulse")
d = smoothness_priors_detrend(100 + 5 * t + pulse * 100, fs)
ok(abs(np.polyfit(t, d, 1)[0]) < 0.5, "smoothness-priors detrend removes a linear drift")

# 4) resolution: resampler + refiner + tracker
ts = np.cumsum(rng.uniform(0.025, 0.045, 400)); x = np.sin(2 * np.pi * 1.25 * ts)
tu, xu, f_out, gap = TemporalResampler().resample(ts, x[:, None], 30.0)
ok(np.max(np.abs(xu[10:-10, 0] - np.sin(2 * np.pi * 1.25 * tu[10:-10]))) < 0.1, "irregular timestamps -> uniform grid (cubic) reproduces a 75 BPM sine")
res = SpectralRefiner().estimate(np.sin(2 * np.pi * (73.3 / 60) * np.arange(300) / 30.0), 30.0)
ok(abs(res.bpm - 73.3) < 0.3, f"parabolic peak interpolation: {res.bpm:.2f} BPM for a 73.3 BPM tone (10 s window)")
tr = HRTracker(); tr.update(72, 0.9); v = tr.update(130, 0.9, dt=1.0); w2 = tr.update(75, 0.1)
ok(v < 80 and w2 == v, "HRTracker rate-limits jumps and ignores low-confidence readings")
stab = ROIStabilizer(); base = np.array([[10, 10], [20, 10], [20, 20], [10, 20]], float)
outs = [stab("a", base + rng.normal(0, 0.5, base.shape), i / 30) for i in range(120)]
ok(np.std([o[0, 0] for o in outs[30:]]) < 0.5 * 0.5, "ROI stabiliser halves detector jitter")
m1 = soft_mask_from_polygon((40, 40), base + [0.0, 0]).sum(); m2 = soft_mask_from_polygon((40, 40), base + [0.3, 0]).sum()
ok(abs(m1 - m2) < 1.0, "soft ROI mask area changes smoothly under sub-pixel shift")
