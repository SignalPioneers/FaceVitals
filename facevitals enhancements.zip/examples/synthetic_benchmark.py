"""
synthetic_benchmark.py - proves the plumbing works and shows WHICH fixes help WHICH failure.

It renders fake face videos with a known heart rate (72 BPM) and the four real-world problems,
then compares:
   BASELINE : hard ROI mean -> POS or CHROM -> FFT peak   (what a plain rPPG app does)
   ENHANCED : EnhancedFrontEnd (skin tone + occlusion + lighting + resolution fixes)

!! This is a SIMULATION. It checks the code does what it claims; it does NOT prove accuracy on real
!! people. Validate on real recordings (UBFC-rPPG, PURE, or MMPD which has skin-tone labels).

Run:   python examples/synthetic_benchmark.py            (full)
       python examples/synthetic_benchmark.py --quick    (1 seed, shorter)
"""
import argparse
import os
import sys
import time

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from facevitals_enhancements import EnhancedFrontEnd                       # noqa: E402
from facevitals_enhancements._common import bandpass, chrom_bvp, pos_bvp, power_spectrum   # noqa: E402

TRUE_HR = 72.0
H, W = 240, 320
FACE_C, FACE_R = np.array([160.0, 125.0]), np.array([62.0, 80.0])
PBV = np.array([0.43, 1.0, 0.69])                      # relative pulse strength in R, G, B
LIGHT_VEC = np.array([1.0, 0.5, 1.5])                  # how strongly each colour channel follows a light change


def base_polys():
    r = lambda x0, x1, y0, y1: np.array([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], float)
    return {"forehead": r(135, 185, 62, 82), "right_cheek": r(110, 138, 112, 152),
            "left_cheek": r(182, 210, 112, 152), "eye_band": r(120, 200, 92, 112),
            "lower_face": r(120, 200, 130, 195)}


SCENARIOS = {
    "1 clean, light skin":        dict(),
    "2 dark skin + dim + glare":  dict(skin=(100, 70, 52), amp=0.0025, illum=0.6, frame_noise=0.004, glare=True),
    "3 mask+sunglasses+hair+hand": dict(mask=True, glasses=True, fringe=True, hand=(24.0, 25.0)),
    "4 lighting flicker + AE step": dict(flicker=(1.6, 0.025), drift=0.08, ae_step=(20.0, 1.12), common_noise=0.004),
    "5 low-res + dropped frames": dict(scale=0.3, frame_noise=0.004, jitter_px=0.5, drops=0.08, ts_jitter=0.006),
    "6 realistic combo":          dict(skin=(150, 108, 86), amp=0.004, illum=0.75, frame_noise=0.003, mask=True,
                                       flicker=(1.6, 0.02), drift=0.05, ae_step=(20.0, 1.10), common_noise=0.003),
    "7 STRESS: all at once":      dict(skin=(100, 70, 52), amp=0.0025, illum=0.6, frame_noise=0.004, glare=True,
                                       mask=True, glasses=True, fringe=True, flicker=(1.6, 0.02), drift=0.06,
                                       ae_step=(20.0, 1.10), common_noise=0.003, scale=0.45, jitter_px=0.5,
                                       drops=0.06, ts_jitter=0.005),
}


def render(cfg, seed, dur, fps=30.0):
    rng = np.random.default_rng(seed)
    skin = np.array(cfg.get("skin", (185, 138, 115)), float)
    amp, illum0 = cfg.get("amp", 0.005), cfg.get("illum", 1.0)
    fnoise, cnoise = cfg.get("frame_noise", 0.0015), cfg.get("common_noise", 0.002)
    scale, jit = cfg.get("scale", 1.0), cfg.get("jitter_px", 0.4)
    yy, xx = np.mgrid[0:H, 0:W]
    ell = ((xx - FACE_C[0]) / FACE_R[0]) ** 2 + ((yy - FACE_C[1]) / FACE_R[1]) ** 2 <= 1.0
    tex = 1.0 + 0.04 * rng.standard_normal((H, W, 1)) + 0.10 * (1 - ((xx - FACE_C[0]) / 90.0) ** 2)[..., None]
    skin_img = skin[None, None, :] * tex
    wall = np.array([140.0, 150.0, 160.0])[None, None, :] * (1 + 0.1 * (xx / W))[..., None]
    f0 = TRUE_HR / 60.0
    glare = np.exp(-(((xx - 150) / 9.0) ** 2 + ((yy - 72) / 7.0) ** 2))[..., None] * np.array([1.0, 1.0, 1.0])
    glare_state = 0.0

    n_nom = int(dur * fps)
    stamps, frames, polys_all, boxes = [], [], [], []
    for i in range(n_nom):
        if rng.random() < cfg.get("drops", 0.0):
            continue
        t = i / fps + rng.normal(0, cfg.get("ts_jitter", 0.0))
        t = max(t, stamps[-1] + 1e-3) if stamps else max(t, 0.0)
        phase = 2 * np.pi * f0 * t - 0.1 * (np.cos(2 * np.pi * 0.1 * t) - 1)
        p = np.sin(phase) + 0.25 * np.sin(2 * phase + 0.8)

        light = np.full(3, illum0)                                     # per-channel light (R,G,B)
        if "flicker" in cfg:                                           # colour-changing ambient flicker (TV / LED)
            light = light * (1 + cfg["flicker"][1] * LIGHT_VEC * np.sin(2 * np.pi * cfg["flicker"][0] * t + 0.7))
        light = light * (1 + cfg.get("drift", 0.0) * LIGHT_VEC * np.sin(2 * np.pi * 0.05 * t))
        if "ae_step" in cfg and t >= cfg["ae_step"][0]:                # auto-exposure / auto-white-balance step
            light = light * (1 + (cfg["ae_step"][1] - 1) * LIGHT_VEC)
        common = 1 + cnoise * rng.standard_normal()

        shift = np.array([1.2 * np.sin(2 * np.pi * 0.25 * t), 0.8 * np.sin(2 * np.pi * 0.17 * t)])
        M = np.float32([[1, 0, shift[0]], [0, 1, shift[1]]])
        face = skin_img * (1 + amp * PBV * p)[None, None, :]
        if cfg.get("glare"):
            glare_state = 0.9 * glare_state + 0.45 * rng.standard_normal()           # fast flickering specular
            face = face + glare * skin[None, None, :] * np.clip(0.35 + 0.08 * glare_state, 0, 1)
        img = wall * (1 + 0.9 * (light - 1))[None, None, :]
        img = np.where(ell[..., None], face * light[None, None, :], img)
        img = img * common
        if cfg.get("mask"):
            img[(yy > 115) & ell] = np.array([170.0, 205.0, 220.0]) * light * common
        if cfg.get("glasses"):
            img[(yy > 94) & (yy < 112) & (xx > 118) & (xx < 202)] = np.array([14.0, 14.0, 18.0])
        if cfg.get("fringe"):
            img[(yy < 72) & (xx > 130) & (xx < 190) & ell] = np.array([50.0, 35.0, 25.0]) * light
        if "hand" in cfg and cfg["hand"][0] <= t <= cfg["hand"][1]:
            img[(yy > 55) & (yy < 95) & (xx > 125) & (xx < 195)] = skin * 1.2 * light
        img = cv2.warpAffine(img.astype(np.float32), M, (W, H), borderMode=cv2.BORDER_REPLICATE)
        img = img * (1 + fnoise * rng.standard_normal(3))[None, None, :]             # per-frame channel noise
        poly_shift = {k: v + shift for k, v in base_polys().items()}
        if scale != 1.0:
            img = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            poly_shift = {k: v * scale for k, v in poly_shift.items()}
        img = img + rng.normal(0, 1.5, img.shape)                                    # per-pixel sensor noise
        frames.append(np.clip(np.round(img[..., ::-1]), 0, 255).astype(np.uint8))   # RGB -> BGR
        polys_all.append({k: v + rng.normal(0, jit, v.shape) for k, v in poly_shift.items()})  # detector jitter
        fb = np.array([FACE_C[0] - FACE_R[0], FACE_C[1] - FACE_R[1], 2 * FACE_R[0], 2 * FACE_R[1]]) * scale
        boxes.append(tuple(fb + np.array([shift[0], shift[1], 0, 0]) * scale))
        stamps.append(t)
    return frames, np.array(stamps), polys_all, boxes


# ----------------------------------------------------------------------------------------- baseline
def fft_peak_bpm(bvp, fs):
    f, p = power_spectrum(bvp, fs, 8)
    s = (f >= 0.7) & (f <= 3.0)
    return float(f[s][np.argmax(p[s])] * 60)


def baseline_run(frames, polys, nominal_fps, eval_idx, win=10.0):
    """hard ROI mean over every pixel; frame index treated as time (typical simple app)."""
    traces = []
    for fr, pl in zip(frames, polys):
        vals = []
        for k in ("forehead", "right_cheek", "left_cheek"):
            m = np.zeros(fr.shape[:2], np.uint8)
            cv2.fillPoly(m, [np.round(pl[k]).astype(np.int32)], 1)
            vals.append(fr[m > 0].mean(axis=0)[::-1] if m.any() else np.zeros(3))
        traces.append(np.mean(vals, axis=0))
    traces = np.array(traces)
    L = int(win * nominal_fps)
    out_pos, out_chr = [], []
    for e in eval_idx:
        seg = traces[max(0, e - L):e]
        out_pos.append(fft_peak_bpm(bandpass(pos_bvp(seg, nominal_fps), nominal_fps), nominal_fps))
        out_chr.append(fft_peak_bpm(bandpass(chrom_bvp(seg, nominal_fps), nominal_fps), nominal_fps))
    return np.array(out_pos), np.array(out_chr)


def enhanced_run(frames, stamps, polys, boxes, eval_times):
    fe = EnhancedFrontEnd(fs_target=30.0)
    out, k, notes = [], 0, set()
    for fr, t, pl, bx in zip(frames, stamps, polys, boxes):
        info = fe.process(fr, float(t), roi_polygons=pl, face_box=bx)
        for m in info.messages:
            notes.add(m)
        while k < len(eval_times) and t >= eval_times[k]:
            s = fe.estimate_hr()
            out.append(np.nan if s is None else s.raw_bpm)
            k += 1
    return np.array(out + [np.nan] * (len(eval_times) - len(out))), fe, notes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", default="", help="comma-separated scenario numbers, e.g. 1,2")
    a = ap.parse_args()
    seeds = [1] if a.quick else [1, 2]
    dur = 30.0 if a.quick else 40.0
    eval_times = np.arange(16.0, dur - 0.5, 2.0)
    print(f"True HR = {TRUE_HR:.0f} BPM. Each cell: mean abs error in BPM (share of windows within +-5 BPM)")
    print(f"{len(eval_times)} windows x {len(seeds)} seed(s) per scenario\n")
    print(f"{'scenario':30s} {'base POS':>14s} {'base CHROM':>14s} {'ENHANCED':>14s}")
    cell = lambda e: f"{np.mean(e):5.1f} ({100 * np.mean(np.array(e) <= 5):3.0f}%)"
    only = {x.strip() for x in a.only.split(',') if x.strip()}
    for name, cfg in SCENARIOS.items():
        if only and name.split()[0] not in only:
            continue
        e_pos, e_chr, e_enh = [], [], []
        for sd in seeds:
            frames, stamps, polys, boxes = render(cfg, sd, dur)
            idx = [int(np.searchsorted(stamps, t)) for t in eval_times]
            bp, bc = baseline_run(frames, polys, 30.0, idx)
            en, fe, nt = enhanced_run(frames, stamps, polys, boxes, eval_times)
            e_pos += list(np.abs(bp - TRUE_HR)); e_chr += list(np.abs(bc - TRUE_HR))
            e_enh += list(np.where(np.isfinite(en), np.abs(en - TRUE_HR), 99.0))      # no estimate = counted as failure
        print(f"{name:30s} {cell(e_pos):>14s} {cell(e_chr):>14s} {cell(e_enh):>14s}", flush=True)


if __name__ == "__main__":
    t0 = time.time()
    main()
    print(f"\n(done in {time.time() - t0:.0f}s)")
